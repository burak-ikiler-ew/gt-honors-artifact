export default {
  lightboxLabel: 'Dies ist ein Dialogfenster, das den Hauptinhalt der Seite überlagert. Das Modal zeigt das vergrößerte Bild. Durch Drücken der Escape-Taste wird das Modal geschlossen und Sie kehren an die Stelle zurück, an der Sie sich auf der Seite befanden.',
  lightboxLoadingIndicatorLabel: 'Bild wird geladen',
  previousButtonLabel: 'Vorheriges Bild',
  nextButtonLabel: 'Nächstes Bild',
  closeButtonLabel: 'Dialogfenster schließen'
}
