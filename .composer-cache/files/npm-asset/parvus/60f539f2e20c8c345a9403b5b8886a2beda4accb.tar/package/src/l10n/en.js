export default {
  lightboxLabel: 'This is a dialog window which overlays the main content of the page. The modal shows the enlarged image. Pressing the Escape key will close the modal and bring you back to where you were on the page.',
  lightboxLoadingIndicatorLabel: 'Image loading',
  previousButtonLabel: 'Previous image',
  nextButtonLabel: 'Next image',
  closeButtonLabel: 'Close dialog window'
}
