# Layout Builder Claro

## Overview
An opinionated attempt at making the transition between the Claro admin theme and a custom themes Layout Builder pages smoother.

Includes a nice wide Off Canvas tray and themed Media Library.

## Requirements
Layout Builder
Claro
Media Library