<?php

namespace Drupal\cas\Exception;

/**
 * Extends \Exception.
 */
class CasValidateException extends \Exception {
}
