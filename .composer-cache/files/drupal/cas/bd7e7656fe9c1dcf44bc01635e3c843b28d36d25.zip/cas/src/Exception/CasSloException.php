<?php

namespace Drupal\cas\Exception;

/**
 * Extends \Exception.
 */
class CasSloException extends \Exception {
}
