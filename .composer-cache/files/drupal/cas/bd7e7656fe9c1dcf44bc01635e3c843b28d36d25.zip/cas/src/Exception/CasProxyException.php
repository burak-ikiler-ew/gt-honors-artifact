<?php

namespace Drupal\cas\Exception;

/**
 * Extends \Exception.
 */
class CasProxyException extends \Exception {
}
