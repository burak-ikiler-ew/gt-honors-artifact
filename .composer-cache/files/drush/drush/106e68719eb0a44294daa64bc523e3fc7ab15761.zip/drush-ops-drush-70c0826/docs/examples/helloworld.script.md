---
edit_url: https://github.com/drush-ops/drush/blob/11.x/examples/helloworld.script
---
```php
--8<-- "examples/helloworld.script"
```
